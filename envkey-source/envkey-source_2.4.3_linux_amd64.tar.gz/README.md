# envkey-source

Integrate [EnvKey](https://www.envkey.com) with any language, either in development or on a server, by making your configuration available through the shell as environment variables.

[Read the docs.](https://docs-v2.envkey.com/docs/envkey-source)
